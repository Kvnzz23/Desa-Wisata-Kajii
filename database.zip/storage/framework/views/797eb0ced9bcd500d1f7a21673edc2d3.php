<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Desa Wisata Kajii</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body>
    <div class="hero">
        <?php echo $__env->make("layouts.navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <section id="Home">
            <div class="content-below-fixed">
                <div class="container">
                    <div class="row mt-3 align-items-center">
                        <div class="col">
                            <img src="image/ikan.png" alt="Programmer">
                        </div>
                        <div class="col text-white">
                            <div class="text">
                                <h1>Desa Wisata Edukasi Ikan Hias</h1>
                                <p class="p1">Dusun Kajii, Kadisoro, Gilangharjo, Kec. Pandak, Kab. Bantul, Daerah Istimewa Yogyakarta 55761</p>
                                <p><button type="button" class="btn btn-warning text-white">Reservasi</button></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html><?php /**PATH C:\Users\tonny\desakajii\resources\views/welcome.blade.php ENDPATH**/ ?>